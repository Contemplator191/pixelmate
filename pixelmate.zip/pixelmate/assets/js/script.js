$(document).ready(function(){
    schools();
});
function schools(){
	$.ajax({
	   url:"http://127.0.0.1:8080/",
	   method:"GET"
	}).done(function(data){
	   var sch, i, json;
	   json = JSON.parse(data);
	   for (i = 0; i < json.length; i++) {
	     $('#ajax-table').append('<option>'+ json[i].name +'</option>');
	   }
	});
}